package BorderControl;

public interface Identifiable {
    String getID();
}
