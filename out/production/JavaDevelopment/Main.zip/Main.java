import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] uninitializedPeople = scanner.nextLine().split(";");
        String[] uninitializedProducts = scanner.nextLine().split(";");
        List<Person> personList = new ArrayList<>();
        Map<String, Product> productList = new HashMap();

        //add Products and People
        try {
            for (int i = 0; i < uninitializedPeople.length; i++) {
                String[] tokens = uninitializedPeople[i].split("=");
                Person person = new Person(tokens[0], Double.parseDouble(tokens[1]));
                personList.add(person);
            }
            for (int i = 0; i < uninitializedPeople.length; i++) {
                String[] tokens = uninitializedProducts[i].split("=");
                Product product = new Product(tokens[0], Double.parseDouble(tokens[1]));
                productList.put(tokens[0], product);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        String input;
        while (!("END").equals(input = scanner.nextLine())){
            String[] tokens = input.split("\\s+");

            String personName = tokens[0];
            String productName = tokens[1];

            Product product = productList.get(productName);
            for (Person person : personList) {
                if (person.getName().equals(personName)){
                    person.buyProduct(product);
                }
            }
        }

        for (Person person : personList) {
            System.out.println(person.printProducts());
        }


    }
}
