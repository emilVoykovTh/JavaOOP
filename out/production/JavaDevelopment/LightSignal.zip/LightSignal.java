public enum LightSignal {
    RED, YELLOW, GREEN
}
