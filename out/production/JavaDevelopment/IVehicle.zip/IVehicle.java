public interface IVehicle {
    String drive(double distance);
    void refuel(double liters);
    String toString();
}
